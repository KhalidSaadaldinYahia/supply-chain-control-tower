# Supply Chain Control Tower

A portfolio-grade Power BI operational intelligence project for monitoring fulfillment, inventory, supplier performance, and working-capital exposure across a synthetic multi-warehouse supply chain.

## Report pages

- **Control Tower** — cross-functional service, inventory, and inbound exceptions.
- **Inventory Intelligence** — stockout exposure, days of supply, ABC/XYZ positioning, and excess capital.
- **Supplier Performance** — supplier OTIF, delay, quality, and late purchase-order exposure.
- **Fulfillment & Logistics** — customer revenue, margin, service performance, and warehouse pressure.
- **Architecture & Methodology** — model design, metric definitions, refresh setup, and engineering choices.

## Technical architecture

- Power BI Project (`.pbip`)
- PBIR report definition
- TMDL semantic model
- Three fact tables with conformed dimensions
- Dedicated `_Measures` layer
- Explicit Date dimension with auto date/time disabled
- Reusable `DataFolder` Power Query parameter
- Custom registered background images and report theme

## Open the project

1. Extract the ZIP.
2. Open `SupplyChainControlTower.pbip` in Power BI Desktop.
3. Open **Transform data → Manage Parameters**.
4. Set `DataFolder` to the extracted `data` folder.
5. Select **Close & Apply**, then refresh.

## Data

The included dataset is synthetic and deterministic, covering 2024–2025. It is intended for portfolio demonstration and reproducible analysis rather than operational use.
